initialData = input()
data = initialData.split()
size1 = float(data[0])
size2 = float(data[1])
size3 = float(data[2])
if (size1 < size2 + size3) and (size2 < size1 + size3) and (size3 < size1 + size2):
    print(1)
else:
    print(0)
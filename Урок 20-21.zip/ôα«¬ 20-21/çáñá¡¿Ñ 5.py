initialData = input()
data = initialData.split()
x = float(data[0])
y = float(data[1])
z = float(data[2])
if (x > 0) and (y > 0) and (z > 0):
    print("1")
elif (x < 0) and (y > 0) and (z > 0):
    print("2")
elif (x < 0) and (y < 0) and (z > 0):
    print("3")
elif (x > 0) and (y < 0) and (z > 0):
    print("4")
elif (x > 0) and (y > 0) and (z < 0):
    print("5")
elif (x < 0) and (y > 0) and (z < 0):
    print("6")
elif (x < 0) and (y < 0) and (z < 0):
    print("7")
elif (x > 0) and (y < 0) and (z < 0):
    print("8")
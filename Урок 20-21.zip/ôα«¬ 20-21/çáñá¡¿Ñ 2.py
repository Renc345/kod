initialData = input()
data = initialData.split()
size1 = float(data[0])
size2 = float(data[1])
size3 = float(data[2])
if (size1 < size2 + size3) and (size2 < size1 + size3) and (size3 < size1 + size2):
    if (size1 == size2 == size3):
        print("РАВНОСТОРОННИЙ")
    elif (size1 == size2) or (size1 == size3) or (size2 == size3):
        print("РАВНОБЕДРЕННЫЙ")
    else:
        print("РАЗНОСТОРОННИЙ")
else:
    print("НЕ ТРЕУГОЛЬНИК")
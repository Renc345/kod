s = input()
if 'р' in s.lower():
    print("Возможно тут есть тигры")
else:
    print("Тигров не обнаружено")

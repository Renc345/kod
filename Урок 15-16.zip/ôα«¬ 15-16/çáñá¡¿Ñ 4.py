x = int(input())
a = x // 100
b = x % 100 // 10
c = x % 10
y = a + b + c
print(a, b, c, sep = "+",end = "=")
print(y)
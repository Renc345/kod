sec1 = int(input())
hour = sec1 // 3600
min = sec1 % 3600 // 60
sec2 = sec1 % 3600 % 60
time = "{:02d}:{:02d}:{:02d}".format(hour,min,sec2)
print(time)
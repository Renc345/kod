a = int(input())
b = int(input())
min_num = (a + b - abs(a - b)) // 2
max_num = (a + b + abs(a - b)) // 2
print(str(min_num) + str(max_num))
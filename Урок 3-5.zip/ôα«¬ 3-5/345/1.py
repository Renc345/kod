﻿a = 7
a = a + 5
print(a)
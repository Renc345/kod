﻿a = input ()
print ("Здравствуйте," , a)
b = input ()
print ("Здравствуйте," , b)

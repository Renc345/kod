﻿a = input ()
print (a)
b = input ()
print (b)

﻿a = input ()
b = input ()
c = input ()
print (a)
print (b)
print (c)


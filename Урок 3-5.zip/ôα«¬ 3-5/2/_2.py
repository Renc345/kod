﻿a = input()
b = input("Введи b")

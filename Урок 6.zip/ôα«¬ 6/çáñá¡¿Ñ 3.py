a = input()
a1 = int(a)
b = input()
b1 = int(b)
c = b1 - a1
print("Отрезок", "[", a, ";", b, "]", "имеет длину", c)
d = input()
d1 = int(d)
e = input()
e1 = int(e)
f = e1 - d1
print("Отрезок", "[", d, ";", e, "]", "имеет длину", f)

a = int(input())
if a%2 == 0:
    print(a + 2)
else:
    print(a + 1)
b = int(input())
if b%2 == 0:
    print(b + 2)
else:
    print(b + 1)
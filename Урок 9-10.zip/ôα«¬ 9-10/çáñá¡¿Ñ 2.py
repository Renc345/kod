a = input()
b = input()
a1 = int(a)
b1 = int(b)
c = 1
while a1 < b1:
    c = c+1
    a1 = a1 + 1
print(c)
a1 = input()
b1 = input()
a11 = int(a1)
b11 = int(b1)
c1 = 1
while a11 < b11:
    c1 = c1+1
    a11 = a11 + 1
print(c1)
a = int(input())
if a < 10:
    print(False)
else:
    a = str(a)
    if a[0] > a[1]:
        print(True)
    else:
        print(False)
b = int(input())
if b < 10:
    print(False)
else:
    b = str(b)
    if b[0] > b[1]:
        print(True)
    else:
        print(False)
c = int(input())
if c < 10:
    print(False)
else:
    c = str(c)
    if c[0] > c[1]:
        print(True)
    else:
        print(False)
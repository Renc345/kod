a = input()
print (f"Слово {a} имеет длину {len(a)}")
a1 = input()
print (f"Слово {a1} имеет длину {len(a1)}")
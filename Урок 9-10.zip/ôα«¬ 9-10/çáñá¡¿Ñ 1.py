a = input()
b = input()
a1 = int(a)
b1 = int(b)
c = b1 - a1
print(c)
a11 = input()
b11 = input()
a111 = int(a11)
b111 = int(b11)
c11 = b111 - a111
print(c11)

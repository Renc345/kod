a =int(input())
if a%2 == 0:
    print(1)
else:
    print(0)
b =int(input())
if b%2 == 0:
    print(1)
else:
    print(0)
a = int(input())
b = int(input())
c = int(input())
x = int(input())
y = (a * x * x) + (b * x) + c
print(y)
a1 = int(input())
b1 = int(input())
c1 = int(input())
x1 = int(input())
y1 = (a1 * x1 * x1) + (b1 * x1) + c1
print(y1)
n = int(input())
n = str(n)
a = int(n[0])
b = int(n[1])
c = a + b
print(c)
n1 = int(input())
n1 = str(n1)
a1 = int(n1[0])
b1 = int(n1[1])
c1 = a1 + b1
print(c1)
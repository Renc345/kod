a = int(input())
b = int(input())
if a > b:
    print(a)
else:
    print(b)
a1 = int(input())
b1 = int(input())
if a1 > b1:
    print(a1)
else:
    print(b1)
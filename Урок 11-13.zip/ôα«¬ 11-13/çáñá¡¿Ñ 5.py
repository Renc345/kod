x = int(input())
y = (5 * x * x) - (3 * x) + 7
print(y)
x1 = int(input())
y1 = (5 * x1 * x1) - (3 * x1) + 7
print(y1)
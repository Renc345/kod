a = int(input())
b = int(input())
y = (a + b) / 2
print(y)
a1 = int(input())
b1 = int(input())
y1= (a1 + b1) / 2
print(y1)
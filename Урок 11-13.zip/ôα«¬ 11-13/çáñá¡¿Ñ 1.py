n = int(input())
k = int(input())
if n > k:
    print(0)
else:
    a = k // n
    print (a)
n1 = int(input())
k1 = int(input())
if n1 > k1:
    print(0)
else:
    a1 = k1 // n1
    print (a1)
import math
a = int(input())
b = int(input())
c = int(input())
p = (a + b + c) / 2
S = p * (p - a) * (p - b) * (p - c)
print(math.sqrt(S))
a1 = int(input())
b1 = int(input())
c1 = int(input())
p1 = (a1 + b1 + c1) / 2
S1 = p1 * (p1 - a1) * (p1 - b1) * (p1 - c1)
print(math.sqrt(S1))

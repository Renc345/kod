n = int(input())
k = int(input())
c = 0
if n > k:
    print(0)
else:
    while c < k:
        c = c + n
    print(c - k)
n1 = int(input())
k1 = int(input())
c1 = 0
if n1 > k1:
    print(0)
else:
    while c1 < k1:
        c1 = c1 + n1
    print(c1 - k1)

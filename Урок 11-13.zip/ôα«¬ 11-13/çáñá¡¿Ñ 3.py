n = int(input())
k = int(input())
a = k % n
print(a)
n1 = int(input())
k1 = int(input())
a1 = k1 % n1
print(a1)
a = input()
b = input()
a = a[0]
b = b[0]
if a < b:
    print("True")
else:
    print("False")
a = input()
b = input()
c = input()
a1 = int(a)
b1 = int(b)
c1 = int(c)
if 7 * c1 == 5 * (a1 + b1):
    print('True')
else:
    print("False")


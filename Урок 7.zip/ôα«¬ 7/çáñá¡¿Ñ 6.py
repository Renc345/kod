a = input()
b = ''
print(b,b,a,b,b)
print(b,a,a,b)
print(a+a+a+a+a)
a1 = input()
b1 = ''
print(b1,b1,a1,b1,b1)
print(b1,a1,a1,b1)
print(a1+a1+a1+a1+a1)


a = input()
a1 = int(a)
b = input()
b1 = int(b)
c = input()
c1 = int(c)
d = input()
d1 = int(d)
list = [a, b, c, d]
count = len(list)
e = a1 + b1 + c1 + d1
print (e/count)
a11 = input()
a111 = int(a11)
b11 = input()
b111 = int(b11)
c11 = input()
c111 = int(c11)
d11 = input()
d111 = int(d11)
list11 = [a11, b11, c11, d11]
count11 = len(list)
e11 = a111 + b111 + c111 + d111
print (e11/count11)
a = input()
b = input()
a1 = int(a)
b1 = int(b)
if a1 + 1 == b1:
    print("True")
else:
    print("False")